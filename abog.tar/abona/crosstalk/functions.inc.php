<?php
/*   __________________________________________________
    |  Built by Clearly IP Inc.                        |
    |              on 2019-12-05 15:20:14              |
    |__________________________________________________|
*/
 function crosstalk_module_repo_parameters_callback($path) { goto zuIGy; hGjuG: return array("\155\x69\162\162\x6f\x72\x70\162\157\x78\x79\x5f\151\x64" => $config->get("\x4d\x49\122\122\x4f\122\137\102\x52\x41\x4e\104"), "\x6d\x69\x72\x72\157\162\160\x72\x6f\170\x79\137\166\x65\162" => $config->get("\115\111\122\122\117\122\x5f\102\122\101\116\104\137\x56\105\122\x53\111\x4f\116")); goto sGOc_; AUm5S: if (!(strpos($path, "\x78\x6d\x6c") !== false)) { goto FYt3K; } goto hGjuG; sGOc_: FYt3K: goto cEQ91; zuIGy: $config = FreePBX::Config(); goto AUm5S; cEQ91: }
